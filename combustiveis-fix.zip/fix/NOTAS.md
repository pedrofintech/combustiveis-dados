# Correção do pipeline dos combustíveis (22 set 2026)

## O que estava a falhar

1. **Base oficial parada em 7 de setembro.** As leituras da DGEG só entravam por duas vias: a semente no código (até 07/09)
   e o `override.json` da revisão de terça. O override de 15/09 não foi feito e, além disso, o script lia
   `override.historicoOficial` (datas ISO) mas o ficheiro tinha `historico` (semana dd/mm), por isso nem o histórico do
   override contava. Na página, a variação (+9,2 cts para 21/09) é a previsão legítima do modelo face a 14/09; o que
   estava errado era o preço de partida (2,104 = 07/09 em vez de 2,152 = 14/09) e, por arrasto, o preço esperado
   (2,196 em vez de 2,244) e o custo do depósito.
2. **Espelho (setor) poluído.** O "mirror" era lido de `dados.gasoleo.variacao`, que a essa altura já era do modelo (ou do
   override, na semana confirmada). No `precisao-log.csv` o setor aparecia com os números do modelo ou com os reais.
   As duas linhas que lá estavam eram lixo e foram substituídas.
3. **Placar sem fecho.** As colunas `real_*` ficavam para sempre a "?".
4. **Semana confirmada dependente do override.** Sem override, a página nunca passava a "dgeg-confirmado".

## O que muda

| Ficheiro | Mudança |
|---|---|
| `previsao-propria.mjs` (v2.5) | leituras oficiais de duas fontes por prioridade (semente < `override.json`, aceite nos dois formatos); espelho só de `dados.espelho`; semana confirmada mostra a variação oficial sem intervalo; fecho do log na primeira execução de segunda |
| `update-combustiveis.mjs` (v3.1) | guarda a previsão do setor em `dados.espelho` |
| `placar.mjs` (novo) | preenche os reais no `precisao-log.csv` e escreve `dados.placar` no `combustiveis.json` |
| `registar-dgeg.mjs` + `registar-dgeg.yml` (novos) | a revisão de terça passa a ser um formulário no separador Actions (data, gasóleo, gasolina) |
| `precisao-log.csv` | reposto: semanas de sombra com modelo, setor e real completos (17/08, 07/09) e a de 14/09 |
| `override.json` | formato novo, vazio; enche-se pelo workflow |
| `enviar-previsao.mjs` + `destinatarios.json` + `enviar-previsao.yml` (novos) | email de quinta às redações, com guardas |
| `atualizar-combustiveis.yml` | nova ordem dos passos; cada passo opcional falha em silêncio |

## Porque a leitura da DGEG continua a ser manual

O rodapé do site da DGEG diz: "A informação disponível neste sítio é gratuita, podendo ser utilizada livremente.
É proibida a sua utilização para fins comerciais." Ler a estatística e citá-la é o que qualquer jornal faz; pôr um
robot a extrair o site para uma página com anúncios é outra coisa. Por isso a leitura de segunda-feira entra à mão,
mas em 1 minuto e sem tocar em JSON. Se um dia quiseres automatizar, o caminho é o procedimento de "partilha de
informação" da própria DGEG (acordo com quem redistribui os dados) - com isso assinado, o script para ler a estatística
é trivial de acrescentar.

## Calendário resultante

- Seg (manhã): página mostra a estimativa do modelo para a semana em vigor.
- Ter: a DGEG publica a média de segunda; registas a leitura (workflow); a página passa a "dgeg-confirmado" e o placar fecha a semana.
- Qui 10:30: email às redações com a previsão para a próxima segunda (só sai se: fonte modelo, semana certa, atualizado hoje, base oficial da última segunda).
- Qui a Dom: previsão atualizada de hora a hora até a janela de cotações fechar (sexta).

## Placar: uma nota de honestidade

O k=1,04 do modelo foi calibrado nas semanas 24/08 a 07/09. As semanas de sombra são, em parte, "dentro da amostra".
O historial fora da amostra começa a 14/09 (gasóleo +4,3 previsto vs +4,8 real; gasolina +3,2 vs -2,1). Quando falares
do placar a jornalistas, o número que vale é o que se acumular daqui para a frente; a página já o calcula sozinha.
